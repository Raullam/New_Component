/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package spdvi.logica;

import spdvi.componentimatge.ImagePanel;

/**
 *
 * @author Rulox
 */
public class RotarImatge {
    
    public static void rotarImagen(ImagePanel imagePanel) {
        imagePanel.rotateImage(90); // Rotar 90 grados
    }
    
}
